from threading import Timer
import time
import random

timer1 = None
timer2 = None

phig1 = 0
phig2 = 0

is_move1 = False
is_move2 = False

duration = 1.0
speed2 = 360.0

start_time2 = 0.0
start_angle2 = 0.0

def move2():
    pass

def move1():
    pass

class Ans:
    h = -101 # мощность сигнала
    phig1 = None
    phig2 = None


def main():
    global phig1, phig2
    move = 1 # шаг в граудсах может быть другой потому что шаговый дивгатель
 
    ans = Ans()
    while phig1 < 360:
        phig2_now = phig2
        while True:
            move2()
            phig2 += move
            if phig2 >= 360:
                phig2 -= 360

            h = A()
            if h >= ans.h:
                ans.h = h
                ans.phig1 = phig1
                ans.phig2 = phig2
            if phig2 - phig2_now < move:
                break
        move1()
        phig1 += move
    print(ans.h, ans.phig1, ans.phig2)


def real_time():
    Hphig1 = -101
    Hphig2 = -101
    while A() >= Hphig1:
        phig1 += move
        move1()
    while A() >= Hphig2:
        phig2 += move
        move2()
    # это можно распараллелить поэтому надо будет перепсиать кодгда будет изевстно какие двигатели
    return 

if __name__ == "__main__":
    main()