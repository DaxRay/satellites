"""Модуль антенны. Здесь только алгоритм и заглушки для отдельного запуска."""


class Ans:
    def __init__(self):
        self.h = float('-inf')
        self.phig1 = 0.0
        self.phig2 = 0.0


class Antenna:
    def __init__(self, modem, gyroscope):
        self.modem = modem
        self.gyroscope = gyroscope
        self.drive = None
        self.mode = 'idle'
        self.ans = Ans()
        self.step = 1.0                 # расстояние между строками поиска, градусы
        self.track_step = 1.0           # пробный шаг сопровождения, градусы
        self.improvement_db = 0.3       # защита от небольшого шума мощности
        self.satellite_angles = (0.0, 0.0)
        self.platform_angles = (0.0, 0.0, 0.0)

    def connect_drive(self, drive):
        self.drive = drive

    def modem_angles(self):
        # Азимут от севера и возвышение НАД ГОРИЗОНТОМ, в градусах.
        return self.modem.angles()

    def gyro_angles(self):
        # Крен, тангаж, курс платформы, в градусах.
        return self.gyroscope.angles()

    def A(self):
        return self.modem.power()

    def move1(self, degrees):
        self.drive.move1(degrees)

    def move2(self, degrees):
        self.drive.move2(degrees)

    def go_to(self, phig1, phig2):
        a, b = self.drive.angles()
        self.move1((phig1-a+180) % 360-180)
        self.move2((phig2-b+180) % 360-180)

    def start(self):
        if self.drive is None:
            raise RuntimeError('Сначала подключи двигатели: connect_drive(drive)')
        if not 0 < self.step <= 360 or not 0 < self.track_step < 180:
            raise ValueError('Проверь step и track_step')
        self.drive.stop()
        self.ans = Ans()
        self.row = 0.0
        self.mode = 'search'
        self.search_state = 'to_start'
        self.go_to(0, 0)
        self.track_state = 'ready'
        self.axis = 1
        self.direction = [1, 1]

    def update(self):
        # Один короткий вызов. Общая прошивка сама выбирает частоту вызовов.
        if self.mode == 'idle':
            return
        self.satellite_angles = self.modem_angles()
        self.platform_angles = self.gyro_angles()
        if self.mode == 'search':
            self.search()
        elif self.mode == 'tracking':
            self.real_time()

    def remember(self):
        h = self.A()
        a, b = self.drive.angles()
        if h > self.ans.h:
            self.ans.h = h
            self.ans.phig1 = a
            self.ans.phig2 = b

    def search(self):
        # Как раньше: перебираем первую призму и полный оборот второй.
        # Теперь во время оборота измеряем сигнал, не задерживая прошивку.
        if self.search_state == 'scan':
            self.remember()
            if self.drive.busy():
                return
            self.row += self.step
            if self.row >= 360:
                self.go_to(self.ans.phig1, self.ans.phig2)
                self.search_state = 'to_best'
            else:
                self.move1(self.step)
                self.search_state = 'to_row'
            return

        if self.drive.busy():
            return
        if self.search_state == 'to_best':
            self.mode = 'tracking'
            return

        self.remember()
        self.move2(360)
        self.search_state = 'scan'

    def real_time(self):
        # Простой исходный вариант: пробуем шаг по одной оси и сравниваем A.
        # Углы модема/гироскопа уже доступны выше, но эта версия ещё
        # не использует их для упреждения движения спутника.
        if self.drive.busy():
            return
        if self.track_state == 'ready':
            self.before_power = self.A()
            self.before_angles = self.drive.angles()
            delta = self.direction[self.axis-1]*self.track_step
            if self.axis == 1:
                self.move1(delta)
            else:
                self.move2(delta)
            self.track_state = 'compare'
            return

        if self.track_state == 'compare':
            if self.A() < self.before_power+self.improvement_db:
                self.go_to(*self.before_angles)
                self.direction[self.axis-1] *= -1
            self.axis = 3-self.axis
            self.track_state = 'ready'

    def stop(self):
        if self.drive is not None:
            self.drive.stop()
        self.mode = 'idle'


class Modem:
    """Заглушка для отдельного запуска. Спутник неподвижен над горизонтом."""
    def angles(self):
        return 55.0, 70.0

    def power(self):
        return -80.0


class Gyroscope:
    """Заглушка: горизонтальная платформа, её нос смотрит на север."""
    def angles(self):
        return 0.0, 0.0, 0.0


if __name__ == '__main__':
    antenna = Antenna(Modem(), Gyroscope())
    print('Модем: азимут, возвышение =', antenna.modem_angles())
    print('Гироскоп: крен, тангаж, курс =', antenna.gyro_angles())
    print('Мощность =', antenna.A(), 'dBm')
    print('Для управления подключи drive и вызывай start(), затем update().')
