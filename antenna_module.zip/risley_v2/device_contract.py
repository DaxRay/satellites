"""Контракт настоящих драйверов. Наследоваться от Protocol не нужно."""
from typing import Protocol


class Modem(Protocol):
    def angles(self) -> tuple[float, float]:
        """Азимут от севера вправо, возвышение над местным горизонтом; градусы."""
        ...

    def power(self) -> float:
        """Текущая измеренная мощность, dBm."""
        ...


class Gyroscope(Protocol):
    def angles(self) -> tuple[float, float, float]:
        """Крен правым бортом вниз, тангаж носом вверх, курс от севера; градусы.

        Требуется ориентация от AHRS, а не скорости сырого гироскопа.
        """
        ...


class Drive(Protocol):
    def move1(self, degrees: float) -> None:
        """Относительный поворот; сразу вернуть управление. Заменяет текущую команду."""
        ...

    def move2(self, degrees: float) -> None:
        ...

    def angles(self) -> tuple[float, float]:
        """Текущие углы [0,360), включая промежуточные положения."""
        ...

    def busy(self) -> bool:
        """Движется хотя бы один двигатель."""
        ...

    def stop(self) -> None:
        """Остановить оба двигателя."""
        ...

    def clock(self) -> float:
        """Монотонные секунды для неблокирующих таймеров алгоритма."""
        ...
