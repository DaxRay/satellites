"""Виртуальные приборы живут только здесь, внутри эмулятора."""


class Modem:
    def __init__(self, backend):
        self.backend = backend

    def angles(self):
        return self.backend.modem_angles()

    def power(self):
        return self.backend.A()


class Gyroscope:
    # angles — оценка ориентации от IMU/AHRS, не интеграл сырого гироскопа.
    def __init__(self, backend):
        self.backend = backend

    def angles(self):
        return self.backend.imu_angles()

    def rates(self):
        return self.backend.gyro_rates()


class Drive:
    def __init__(self, backend):
        self.backend = backend

    def move1(self, degrees):
        self.backend.move1(degrees)

    def move2(self, degrees):
        self.backend.move2(degrees)

    def angles(self):
        return self.backend.motor_angles()

    def busy(self):
        return any(self.backend.motors_busy())

    def stop(self):
        self.backend.stop1()
        self.backend.stop2()

    def clock(self):
        return self.backend.now
