"""Пустой шаблон класса. Наведения нет; рабочий пример лежит в ../main.py."""


class Antenna:
    def __init__(self, modem, gyroscope):
        self.modem = modem
        self.gyroscope = gyroscope
        self.mode = 'idle'

    def connect_drive(self, drive):
        self.drive = drive

    def start(self):
        self.mode = 'search'

    def update(self):
        az, el = self.modem.angles()
        roll, pitch, yaw = self.gyroscope.angles()
        h = self.modem.power()
        if self.mode == 'search':
            # Здесь поиск. Переключай mode после реального наведения.
            self.mode = 'tracking'
        elif self.mode == 'tracking':
            self.real_time()

    def real_time(self):
        # Здесь команды двигателям. Без постоянного while/sleep.
        pass

    def stop(self):
        self.drive.stop()
        self.mode = 'idle'
