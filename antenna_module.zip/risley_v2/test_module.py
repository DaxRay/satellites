"""Проверки контракта Antenna и движения платформы. Без дополнительной установки."""
import hashlib
import importlib.util
import math
import sys
import tempfile
from pathlib import Path

import config as c
import vectors as v
import runner
from model import Model
from orbit import Platform, station_ecef, ecef_to_enu


def test_sensors():
    old = dict(vars(c))
    try:
        c.modem_noise_deg = c.imu_noise_deg = 0
        c.modem_latency_seconds = c.imu_latency_seconds = 0
        m = Model()
        sat = m.target('flight', 40)
        az, el = m.modem('flight', 40)
        assert abs(az-sat['az']) < 1e-9 and abs(el-sat['el']) < 1e-9
        assert v.norm(v.sub(v.azel_vector(az, el), sat['vector'])) < 1e-12
        assert m.imu('flight', 40) == tuple(x if i < 2 else x%360 for i,x in enumerate(m.pose(40)))
        # Меняем ориентацию, но сохраняем время и координаты: модем тот же.
        original = m.target('flight', 40)
        c.roll_amplitude_deg = 35
        rotated = m.target('flight', 40)
        assert original['vector'] == rotated['vector']
        assert original['body_vector'] != rotated['body_vector']
        # Меняем положение при ОДНОМ UTC: углы изменяются даже без движения спутника.
        fixed = m.orbit.at_jd(m.orbit.base_jd, 0)
        shifted = m.orbit.at_jd(m.orbit.base_jd, 600)
        assert v.angle(fixed['vector'], shifted['vector']) > .01
        assert m.target('search', 999)['platform_position'] == m.target('search', 0)['platform_position']
        # Независимо проверяем скорость через разность ECEF координат за 0.1 с.
        c.heave_amplitude_m = 0
        p = Platform()
        a, b = p.at(0), p.at(.1)
        delta = v.scale(v.sub(station_ecef(*b), station_ecef(*a)), 10000)
        east, north, up = ecef_to_enu(delta, a[0], a[1])
        assert abs(east-c.platform_east_m_s) < 1e-4
        assert abs(north-c.platform_north_m_s) < 1e-4
        assert abs(up) < 1e-4
        c.platform_east_m_s = c.platform_north_m_s = 0
        p = Platform()
        assert max(abs(x-y) for x,y in zip(p.at(0),p.at(3600))) < 1e-10
    finally:
        for name, value in old.items():
            setattr(c, name, value)


def test_module():
    source = '''
class Antenna:
    def __init__(self, modem, gyroscope):
        assert 'A' not in globals() and 'move1' not in globals()
        self.modem, self.gyroscope = modem, gyroscope
        self.mode = 'idle'
    def connect_drive(self, drive):
        self.drive = drive
    def start(self):
        self.mode = 'search'
        self.begin = self.drive.clock()
        self.drive.move1(90)
        self.drive.move2(180)
        assert self.drive.busy()
        assert self.drive.clock()-self.begin < .01
        self.midpoint = False
        self.checked = False
    def update(self):
        assert 'phig2' not in globals()
        az, el = self.modem.angles()
        roll, pitch, yaw = self.gyroscope.angles()
        h = self.modem.power()
        elapsed = self.drive.clock()-self.begin
        if .45 < elapsed < .55:
            a, b = self.drive.angles()
            assert 39 < a < 51 and 79 < b < 101
            self.midpoint = True
        if not self.drive.busy() and self.mode == 'search':
            assert self.midpoint
            assert self.drive.angles() == (90, 180)
            self.mode = 'tracking'
        if self.mode == 'tracking':
            self.real_time()
    def real_time(self):
        if not self.checked:
            self.drive.move1(60)
            self.drive.stop()
            assert not self.drive.busy()
            self.checked = True

if __name__ == '__main__':
    raise RuntimeError('Standalone block must not execute during import')
'''
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder)/'main.py'
        path.write_text(source, encoding='utf-8')
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        r = runner.run(path, settings={'flight_seconds':2, 'turn_seconds':1})
        assert r['error'] is None, r['error']
        assert r['execution_mode'] == 'antenna'
        assert r['search']['ended'] == 'tracking'
        assert r['flight']['controller_seen']
        assert r['flight']['modem_calls'] > 50 and r['flight']['imu_calls'] > 50
        assert before == hashlib.sha256(path.read_bytes()).hexdigest()
        # Изменение main читается при следующем запуске; ошибки не скрываются.
        path.write_text(source.replace("assert 'A' not in globals() and 'move1' not in globals()", "raise ValueError('fresh source read')"), encoding='utf-8')
        r = runner.run(path, settings={'flight_seconds':.2})
        assert 'fresh source read' in r['error']


def test_standalone():
    path = Path(__file__).resolve().parent.parent/'main.py'
    spec = importlib.util.spec_from_file_location('antenna_under_test', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    antenna = module.Antenna(module.Modem(), module.Gyroscope())
    assert antenna.gyro_angles() == (0, 0, 0)
    assert antenna.modem_angles() == (55, 70)
    assert antenna.A() == -80
    assert not any(name.startswith('risley') for name in module.__dict__)


if __name__ == '__main__':
    test_sensors()
    print('PASS: moving WGS84 platform, horizon vs body, frozen acquisition, sensor frames')
    test_module()
    print('PASS: two injected sensors, async motors, tracking, fresh source, untouched main')
    test_standalone()
    print('PASS: standalone stubs; no simulator dependency in main')
