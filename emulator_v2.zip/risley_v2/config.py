"""Параметры испытательного стенда. Алгоритм пользователя — только в main.py."""

# Исторический TLE ISS из примера python-sgp4. Испытание идёт возле его эпохи.
# Для своего спутника замени обе строки и время старта, а не только название.
tle_name = 'ISS — архивный контрольный пролёт'
tle1 = '1 25544U 98067A   19343.69339541  .00001764  00000-0  38792-4 0  9991'
tle2 = '2 25544  51.6439 211.2001 0007417  17.6667  85.6398 15.50103472202482'
station_lat_deg = 50.0
station_lon_deg = 10.0
station_height_m = 150.0
start_utc = ''              # пусто: найти высокий пролёт возле эпохи TLE
minimum_elevation_deg = 5.0
search_pass_hours = 48.0
start_before_peak_seconds = 20.0
flight_seconds = 600.0
search_limit_seconds = 7200.0

# Реальный материал Rexolite 1422: eps_r=2.53, tan(delta)=0.00066 при 10 ГГц.
# Размеры ниже — выбранная конструкция стенда, не паспорт готового изделия.
epsilon_r = 2.53
loss_tangent = 0.00066
frequency_ghz = 10.0
wedge1_deg = 20.0
wedge2_deg = 20.0
prism_radius_m = 0.15
min_thickness_m = 0.010
air_gap_m = 0.040
feed_gap_m = 0.025
feed_diameter_m = 0.20
feed_efficiency = 0.60
feed_hpbw_deg = 9.0         # косинусная модель главного лепестка, полная ширина -3 дБ
eirp_dbw = 38.0
other_loss_db = 2.0
floor_dbm = -110.0
link_threshold_dbm = -85.0
noise_db = 0.15

# На первом этапе и спутник, и платформа заморожены. На втором движутся оба.
roll_amplitude_deg = 6.0
pitch_amplitude_deg = 4.0
yaw_amplitude_deg = 8.0
roll_period_seconds = 45.0
pitch_period_seconds = 70.0
yaw_period_seconds = 100.0
yaw_rate_deg_s = 0.15
initial_yaw_deg = 0.0       # курс 0° — продольная ось на север
imu_noise_deg = 0.05
imu_latency_seconds = 0.010
imu_rate_hz = 100.0
modem_noise_deg = 0.02
modem_latency_seconds = 0.050
modem_rate_hz = 10.0

# legacy step: main сам считает phig1/phig2. Новый модуль device — асинхронный.
motor_mode = 'auto'
step_deg = 1.0
step_seconds = 0.02
default_turn2_deg = 360.0
turn_seconds = 1.0
update_main_angles = False
measure_seconds = 0.005
python_line_seconds = 0.00001
sample_seconds = 0.1
controller_period_seconds = 0.02
stable_lock_seconds = 1.0
seed = 42
speed = 100.0
wall_timeout_seconds = 180.0

# Численный эталон строится отдельно от алгоритма, значения в main не передаются.
oracle_relative_samples = 1440
oracle_tolerance_deg = 0.10
