"""Четыре точных геометрических преломления. Приближения sin(a)=a нет."""
import math
from functools import lru_cache
import config as c
from vectors import add, sub, scale, dot, norm, unit, angle


def refract(d, normal, n1, n2):
    d, normal = unit(d), unit(normal)
    if dot(d, normal) > 0:
        normal = scale(normal, -1)
    cosine = -dot(d, normal)
    eta = n1/n2
    k = 1-eta*eta*(1-cosine*cosine)
    if k < -1e-12:
        return None, 0.0
    cost = math.sqrt(max(0, k))
    out = unit(add(scale(d, eta), scale(normal, eta*cosine-cost)))
    rs = (n1*cosine-n2*cost)/(n1*cosine+n2*cost)
    rp = (n1*cost-n2*cosine)/(n1*cost+n2*cosine)
    return out, max(0, 1-(rs*rs+rp*rp)/2)


def surface_hit(point, d, center, normal):
    denominator = dot(d, normal)
    if abs(denominator) < 1e-12:
        return None
    t = dot(sub(center, point), normal)/denominator
    if t < -1e-10:
        return None
    hit = add(point, scale(d, t))
    if math.hypot(hit[0], hit[1]) > c.prism_radius_m+1e-10:
        return None
    return hit


def geometry():
    b1, b2 = math.radians(c.wedge1_deg), math.radians(c.wedge2_deg)
    center1 = c.min_thickness_m+c.prism_radius_m*math.tan(b1)
    center2 = c.min_thickness_m+c.prism_radius_m*math.tan(b2)
    z1 = c.feed_gap_m
    z2 = z1+c.min_thickness_m+2*c.prism_radius_m*math.tan(b1)+c.air_gap_m
    return z1, z1+center1, z2, z2+center2


@lru_cache(maxsize=150000)
def trace(phi1, phi2):
    n = math.sqrt(c.epsilon_r)
    z1, z1out, z2, z2out = geometry()
    surfaces = []
    for phi, wedge, zin, zout in [(phi1, c.wedge1_deg, z1, z1out), (phi2, c.wedge2_deg, z2, z2out)]:
        p, b = math.radians(phi), math.radians(wedge)
        tilted = (math.sin(b)*math.cos(p), math.sin(b)*math.sin(p), math.cos(b))
        surfaces += [((0, 0, zin), (0, 0, -1), 1.0, n),
                     ((0, 0, zout), tilted, n, 1.0)]
    point, direction = (0, 0, 0), (0, 0, 1)
    path = [point]
    transmission = 1.0
    reason = ''
    for center, normal, n1, n2 in surfaces:
        hit = surface_hit(point, direction, center, normal)
        if hit is None:
            reason = 'Луч не попал в рабочую грань'
            break
        if n1 > 1:
            k0 = 2*math.pi*c.frequency_ghz*1e9/299792458
            transmission *= math.exp(-k0*n1*c.loss_tangent*norm(sub(hit, point)))
        path.append(hit)
        direction, passed = refract(direction, normal, n1, n2)
        transmission *= passed
        point = hit
        if direction is None:
            reason = 'Полное внутреннее отражение'
            break
    return {'valid': not reason, 'reason': reason, 'direction': direction if not reason else None,
            'path': path, 'transmission': transmission if not reason else 0.0}


def pointing_loss(error_deg):
    if error_deg >= 90:
        return float('inf')
    exponent = math.log(0.5)/math.log(math.cos(math.radians(c.feed_hpbw_deg/2)))
    cosine = max(1e-300, math.cos(math.radians(error_deg)))
    return -10*exponent*math.log10(cosine)


class Oracle:
    """Осесимметрия сокращает численный эталон до относительного угла дисков."""
    def __init__(self):
        self.samples = []
        for i in range(c.oracle_relative_samples):
            delta = i*360/c.oracle_relative_samples
            ray = trace(0, delta)
            if ray['valid']:
                d = ray['direction']
                theta = math.degrees(math.atan2(math.hypot(d[0], d[1]), d[2]))
                phi = math.degrees(math.atan2(d[1], d[0]))
                self.samples.append((theta, phi, delta, -10*math.log10(max(1e-30, ray['transmission']))))
        if not self.samples:
            raise ValueError('Выбранная геометрия не пропускает ни одного центрального луча')
        self.min_theta = min(x[0] for x in self.samples)
        self.max_theta = max(x[0] for x in self.samples)

    @lru_cache(maxsize=8192)
    def at_theta(self, theta):
        closest = min(self.samples, key=lambda x: abs(x[0]-theta))
        candidate = min(self.samples, key=lambda x: x[3]+pointing_loss(abs(theta-x[0])))
        return {'angular_miss': abs(closest[0]-theta), 'loss_db': candidate[3]+pointing_loss(abs(theta-candidate[0])),
                'phi': candidate[1], 'delta': candidate[2]}

    def evaluate(self, target):
        target = unit(target)
        theta = round(math.degrees(math.atan2(math.hypot(target[0], target[1]), target[2])), 5)
        value = dict(self.at_theta(theta))
        az = math.degrees(math.atan2(target[1], target[0]))
        a = (az-value['phi']) % 360
        value['angles'] = (a, (a+value['delta']) % 360)
        value['reachable'] = value['angular_miss'] <= c.oracle_tolerance_deg
        return value
