"""Пример структуры. Это отдельный шаблон, твой main.py не заменяется.

Сюда можно перенести свой алгоритм. Пока здесь только опрос датчиков:
такой шаблон закономерно получит низкую оценку наведения.
"""
from device import (A, modem_angles, imu_angles, gyro_rates,
                    move1, move2, set_angles, motor_angles, motors_busy, sleep, clock)


def acquire():
    # Спутник и платформа стоят. Здесь твой первоначальный поиск.
    azimuth, elevation = modem_angles()
    roll, pitch, yaw = imu_angles()
    signal = A()
    phi1, phi2 = motor_angles()
    return signal, phi1, phi2


def track_step():
    # Один вызов ≈ один тик прошивки. Спутник и платформа движутся.
    azimuth, elevation = modem_angles()
    roll, pitch, yaw = imu_angles()
    signal = A()
    # Здесь вычисляй команды и вызывай move1/move2 либо set_angles.
    # Пока двигатели работают, обработчик может продолжать читать A().
    # Переменные, нужные между тиками, храни в глобальных переменных main.
