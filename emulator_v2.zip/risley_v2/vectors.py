import math


def add(a, b):
    return tuple(x+y for x, y in zip(a, b))


def sub(a, b):
    return tuple(x-y for x, y in zip(a, b))


def scale(a, k):
    return tuple(x*k for x in a)


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def norm(a):
    return math.sqrt(dot(a, a))


def unit(a):
    n = norm(a)
    if n <= 1e-15:
        raise ValueError('Нулевой вектор нельзя нормировать')
    return scale(a, 1/n)


def angle(a, b):
    return math.degrees(math.acos(max(-1, min(1, dot(unit(a), unit(b))))))


def matvec(m, v):
    return tuple(dot(row, v) for row in m)


def transpose(m):
    return tuple(zip(*m))


def matmul(a, b):
    return tuple(tuple(dot(row, col) for col in zip(*b)) for row in a)


def rx(a):
    c, s = math.cos(a), math.sin(a)
    return ((1, 0, 0), (0, c, -s), (0, s, c))


def ry(a):
    c, s = math.cos(a), math.sin(a)
    return ((c, 0, s), (0, 1, 0), (-s, 0, c))


def rz(a):
    c, s = math.cos(a), math.sin(a)
    return ((c, -s, 0), (s, c, 0), (0, 0, 1))


def attitude(roll, pitch, yaw):
    # ENU — восток, север, вверх. Body — вперёд, влево, вверх.
    # Курс вправо от севера, тангаж носом вверх, крен правым бортом вниз.
    return matmul(matmul(rz(math.radians(90-yaw)), ry(math.radians(-pitch))), rx(math.radians(roll)))


def azel_vector(az, el):
    a, e = math.radians(az), math.radians(el)
    return (math.cos(e)*math.sin(a), math.cos(e)*math.cos(a), math.sin(e))


def vector_azel(v):
    x, y, z = unit(v)
    return (math.degrees(math.atan2(x, y)) % 360,
            math.degrees(math.atan2(z, math.hypot(x, y))))
