"""Контрольные проверки без pytest. Запуск: python test_physics.py."""
import math
import tempfile
from pathlib import Path
import sys
import vectors as v
import prisms
import config as c
from model import Model
from orbit import check_tle
from sgp4.model import Satrec


def run_tests():
    passed=[]
    for angle in (0,10,35,70):
        a=math.radians(angle)
        d=(math.sin(a),0,math.cos(a))
        out,t=prisms.refract(d,(0,0,-1),1,math.sqrt(2.53))
        transmitted=math.acos(out[2])
        assert abs(math.sin(a)-math.sqrt(2.53)*math.sin(transmitted))<1e-12
        back,_=prisms.refract(v.scale(out,-1),(0,0,1),math.sqrt(2.53),1)
        assert v.norm(v.sub(back,v.scale(d,-1)))<1e-12
        assert 0<=t<=1
    assert prisms.refract((math.sin(math.radians(60)),0,0.5),(0,0,-1),1.59,1)[0] is None
    passed.append('Снеллиус, обратимость, потери и полное внутреннее отражение')
    for roll,pitch,yaw in [(0,0,0),(20,30,40),(-65,89,280)]:
        r=v.attitude(roll,pitch,yaw)
        identity=v.matmul(v.transpose(r),r)
        assert max(abs(identity[i][j]-(i==j)) for i in range(3) for j in range(3))<1e-12
        x,y,z=v.transpose(r)
        cross=(x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0])
        assert abs(v.dot(cross,z)-1)<1e-12
    assert v.angle(v.matvec(v.attitude(0,0,0),(1,0,0)),(0,1,0))<1e-8
    assert v.angle(v.matvec(v.attitude(0,0,90),(1,0,0)),(1,0,0))<1e-8
    passed.append('Правая ENU/body, полные повороты и соглашения о курсе')
    # Публичный контрольный вектор Vallado, спутник 00005, t=0.
    l1='1 00005U 58002B   00179.78495062  .00000023  00000-0  28098-4 0  4753'
    l2='2 00005  34.2682 348.7242 1859667 331.7664  19.3264 10.82419157413667'
    sat=Satrec.twoline2rv(l1,l2)
    err,r,velocity=sat.sgp4(sat.jdsatepoch,sat.jdsatepochF)
    expected=(7022.46529266,-1400.08296755,0.03995155)
    assert err==0 and max(abs(a-b) for a,b in zip(r,expected))<1e-6
    passed.append('SGP4: опубликованный контрольный вектор Vallado')
    m=Model()
    assert m.orbit.at(0)['visible']
    assert abs(v.norm(m.orbit.at(0)['vector'])-1)<1e-12
    assert m.orbit.age_days<2
    check_tle(c.tle1,1);check_tle(c.tle2,2)
    failed=False
    try:check_tle(c.tle1[:-1]+'0',1)
    except ValueError:failed=True
    assert failed
    passed.append('TLE: контрольные суммы, эпоха и найденный пролёт')
    for a,b in [(0,0),(0,180),(37,129),(290,315)]:
        ray=prisms.trace(a,b)
        assert ray['valid'] and len(ray['path'])==5
        assert abs(v.norm(ray['direction'])-1)<1e-12
        assert 0<ray['transmission']<1
        rotated=prisms.trace(a+33,b+33)
        expected=v.matvec(v.rz(math.radians(33)),ray['direction'])
        assert v.norm(v.sub(rotated['direction'],expected))<1e-12
    assert abs(prisms.trace(0,180)['direction'][0])>0.01
    passed.append('Четыре грани, осесимметрия и отличие от малых углов')
    # Гироскопные скорости проверяем по производной матрицы, а не той же формуле.
    for t in (0,7,27):
        h=1e-4
        a,b=v.attitude(*m.pose(t-h)),v.attitude(*m.pose(t+h))
        rd=tuple(tuple((b[i][j]-a[i][j])/(2*h) for j in range(3)) for i in range(3))
        spin=v.matmul(v.transpose(v.attitude(*m.pose(t))),rd)
        numerical=(spin[2][1],spin[0][2],spin[1][0])
        assert max(abs(a-b) for a,b in zip(numerical,m.rates(t)))<1e-8
    passed.append('Угловые скорости: независимая проверка производной R(t)')
    assert m.modem('flight',1.001)==m.modem('flight',1.002)
    assert m.imu('flight',1.0001)==m.imu('flight',1.0002)
    assert m.pose(0)==(0,0,c.initial_yaw_deg)
    assert m.target('search',100)['vector']==m.target('search',0)['vector']
    assert m.target('flight',10)['vector']!=m.target('flight',0)['vector']
    passed.append('Задержки/дискретность датчиков, заморозка и движение спутника')
    return passed


if __name__=='__main__':
    for name in run_tests():print('OK:',name)
