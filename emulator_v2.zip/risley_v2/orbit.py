"""TLE -> SGP4/TEME -> вращающаяся Земля -> геодезическая ENU станции."""
import datetime as dt
import math
import sys
from functools import lru_cache
from pathlib import Path
sys.path.insert(0, str(Path(__file__).with_name('vendor')))
from sgp4.model import Satrec
from sgp4.api import SGP4_ERRORS
import config as c
from vectors import sub, norm, unit


def jd_to_datetime(jd):
    return dt.datetime.fromtimestamp((jd-2440587.5)*86400, dt.timezone.utc)


def datetime_to_jd(text):
    value = dt.datetime.fromisoformat(text.replace('Z', '+00:00'))
    if value.tzinfo is None:
        raise ValueError('start_utc требует часовой пояс, например 2019-12-10T12:00:00Z')
    return value.timestamp()/86400+2440587.5


def gstime(jd):
    # IAU-82 GMST, совместимая с традиционным TEME->PEF Vallado.
    t = (jd-2451545.0)/36525
    seconds = 67310.54841+(876600*3600+8640184.812866)*t+0.093104*t*t-6.2e-6*t*t*t
    return math.radians((seconds/240) % 360)


def station_ecef(lat_deg, lon_deg, height_m):
    a, e2 = 6378.137, 6.69437999014e-3  # WGS84, км
    lat, lon = math.radians(lat_deg), math.radians(lon_deg)
    n = a/math.sqrt(1-e2*math.sin(lat)**2)
    h = height_m/1000
    return ((n+h)*math.cos(lat)*math.cos(lon), (n+h)*math.cos(lat)*math.sin(lon),
            (n*(1-e2)+h)*math.sin(lat))


def ecef_to_enu(v, lat_deg, lon_deg):
    lat, lon = math.radians(lat_deg), math.radians(lon_deg)
    x, y, z = v
    return (-math.sin(lon)*x+math.cos(lon)*y,
            -math.sin(lat)*math.cos(lon)*x-math.sin(lat)*math.sin(lon)*y+math.cos(lat)*z,
            math.cos(lat)*math.cos(lon)*x+math.cos(lat)*math.sin(lon)*y+math.sin(lat)*z)


def check_tle(line, number):
    if len(line) != 69 or not line.startswith(str(number)+' '):
        raise ValueError(f'Строка TLE {number} должна содержать ровно 69 символов')
    checksum = sum(int(x) if x.isdigit() else 1 if x == '-' else 0 for x in line[:68]) % 10
    if not line[68].isdigit() or checksum != int(line[68]):
        raise ValueError(f'Неверная контрольная сумма строки TLE {number}')


class Orbit:
    def __init__(self):
        check_tle(c.tle1, 1)
        check_tle(c.tle2, 2)
        if c.tle1[2:7] != c.tle2[2:7]:
            raise ValueError('Две строки TLE относятся к разным спутникам')
        self.sat = Satrec.twoline2rv(c.tle1, c.tle2)
        self.epoch_jd = self.sat.jdsatepoch+self.sat.jdsatepochF
        self.station = station_ecef(c.station_lat_deg, c.station_lon_deg, c.station_height_m)
        self.base_jd = datetime_to_jd(c.start_utc) if c.start_utc else self.find_pass()
        self.age_days = self.base_jd-self.epoch_jd

    def at_jd(self, jd):
        whole = math.floor(jd)
        error, r, velocity = self.sat.sgp4(whole, jd-whole)
        if error:
            raise ValueError('SGP4: '+SGP4_ERRORS.get(error, str(error)))
        g = gstime(jd)
        x, y, z = r
        ecef = (math.cos(g)*x+math.sin(g)*y, -math.sin(g)*x+math.cos(g)*y, z)
        local = ecef_to_enu(sub(ecef, self.station), c.station_lat_deg, c.station_lon_deg)
        distance = norm(local)
        e, n, u = local
        az = math.degrees(math.atan2(e, n)) % 360
        el = math.degrees(math.atan2(u, math.hypot(e, n)))
        return {'az': az, 'el': el, 'range': distance, 'vector': unit(local),
                'visible': el >= c.minimum_elevation_deg,
                'utc': jd_to_datetime(jd).isoformat(timespec='milliseconds')}

    @lru_cache(maxsize=32768)
    def at(self, seconds):
        return self.at_jd(self.base_jd+seconds/86400)

    def find_pass(self):
        # Ищем реальный высокий пролёт у выбранной станции возле эпохи TLE.
        best = (-90, 0)
        for t in range(0, int(c.search_pass_hours*3600)+1, 30):
            el = self.at_jd(self.epoch_jd+t/86400)['el']
            if el > best[0]:
                best = el, t
        peak = best[1]
        for t in range(max(0, peak-30), peak+31):
            el = self.at_jd(self.epoch_jd+t/86400)['el']
            if el > best[0]:
                best = el, t
        if best[0] < c.minimum_elevation_deg:
            raise ValueError('За заданное окно спутник не виден со станции. Измени станцию, TLE или окно поиска.')
        return self.epoch_jd+(best[1]-c.start_before_peak_seconds)/86400
