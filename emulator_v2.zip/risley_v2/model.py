import math
import random
from functools import lru_cache
import config as c
import vectors as v
import prisms
from orbit import Orbit


def validate():
    positive = ['frequency_ghz','prism_radius_m','min_thickness_m','air_gap_m','feed_gap_m',
                'feed_diameter_m','feed_hpbw_deg','epsilon_r','step_deg','step_seconds',
                'turn_seconds','measure_seconds','python_line_seconds','sample_seconds',
                'controller_period_seconds','flight_seconds','search_limit_seconds','speed',
                'roll_period_seconds','pitch_period_seconds','yaw_period_seconds',
                'modem_rate_hz','imu_rate_hz','oracle_relative_samples','search_pass_hours']
    for name in positive:
        x = getattr(c, name)
        if not isinstance(x, (int, float)) or not math.isfinite(x) or x <= 0:
            raise ValueError(name+' должно быть положительным числом')
    for name, x in vars(c).items():
        if isinstance(x, (float, int)) and not math.isfinite(x):
            raise ValueError(name+' должно быть конечным числом')
    if not (0 < c.wedge1_deg < 60 and 0 < c.wedge2_deg < 60):
        raise ValueError('Углы клиньев должны быть в диапазоне (0, 60)°')
    if c.epsilon_r <= 1 or not (0 < c.feed_efficiency <= 1) or not (0 < c.feed_hpbw_deg < 90):
        raise ValueError('Проверь epsilon_r, feed_efficiency и feed_hpbw_deg')
    if c.motor_mode not in ('auto','step','continuous'):
        raise ValueError('motor_mode: auto, step или continuous')
    if not (-90 <= c.station_lat_deg <= 90 and -180 <= c.station_lon_deg <= 180):
        raise ValueError('Проверь координаты станции')
    for name in ['noise_db','imu_noise_deg','modem_noise_deg','imu_latency_seconds',
                 'modem_latency_seconds','loss_tangent']:
        if getattr(c,name) < 0:
            raise ValueError(name+' не может быть отрицательным')


class Model:
    def __init__(self):
        validate()
        prisms.trace.cache_clear()
        self.orbit = Orbit()
        self.oracle = prisms.Oracle()
        self.modem_calls = self.imu_calls = 0
        self.modem_cache = self.imu_cache = None
        self.static_target = None
        wavelength = 299792458/(c.frequency_ghz*1e9)
        self.feed_gain_db = 10*math.log10(c.feed_efficiency*(math.pi*c.feed_diameter_m/wavelength)**2)

    def pose(self, t):
        return (c.roll_amplitude_deg*math.sin(2*math.pi*t/c.roll_period_seconds),
                c.pitch_amplitude_deg*math.sin(2*math.pi*t/c.pitch_period_seconds),
                c.initial_yaw_deg+c.yaw_rate_deg_s*t+c.yaw_amplitude_deg*math.sin(2*math.pi*t/c.yaw_period_seconds))

    def rates(self, t):
        roll, pitch, yaw = self.pose(t)
        rd = math.radians(c.roll_amplitude_deg*2*math.pi/c.roll_period_seconds*math.cos(2*math.pi*t/c.roll_period_seconds))
        pd = math.radians(c.pitch_amplitude_deg*2*math.pi/c.pitch_period_seconds*math.cos(2*math.pi*t/c.pitch_period_seconds))
        yd = math.radians(c.yaw_rate_deg_s+c.yaw_amplitude_deg*2*math.pi/c.yaw_period_seconds*math.cos(2*math.pi*t/c.yaw_period_seconds))
        r, p = math.radians(roll), math.radians(pitch)
        return (rd-yd*math.sin(p), -pd*math.cos(r)-yd*math.sin(r)*math.cos(p),
                pd*math.sin(r)-yd*math.cos(r)*math.cos(p))

    def target(self, phase, seconds):
        if phase == 'search' and self.static_target is not None:
            return self.static_target
        t = seconds if phase == 'flight' else 0.0
        sat = dict(self.orbit.at(round(t, 9)))
        pose = self.pose(t)
        rotation = v.attitude(*pose)
        sat.update(body_vector=v.matvec(v.transpose(rotation), sat['vector']), pose=pose, rotation=rotation)
        if phase == 'search':
            self.static_target = sat
        return sat

    def baseline(self, sat):
        fspl = 92.45+20*math.log10(c.frequency_ghz)+20*math.log10(sat['range'])
        return c.eirp_dbw+30+self.feed_gain_db-fspl-c.other_loss_db

    def observe(self, a, b, sat, reference=False):
        ray = prisms.trace(round(a%360, 8), round(b%360, 8))
        error = v.angle(ray['direction'], sat['body_vector']) if ray['valid'] else 180.0
        power = c.floor_dbm
        if ray['valid'] and sat['visible']:
            power = max(c.floor_dbm, self.baseline(sat)+10*math.log10(max(1e-30,ray['transmission']))-prisms.pointing_loss(error))
        result = {'power': power, 'error': error, 'ray': ray}
        if reference:
            oracle = self.oracle.evaluate(sat['body_vector'])
            result['reference'] = max(c.floor_dbm, self.baseline(sat)-oracle['loss_db']) if sat['visible'] else c.floor_dbm
            result['reachable'] = bool(sat['visible'] and oracle['reachable'])
            result['serviceable'] = result['reachable'] and result['reference'] >= c.link_threshold_dbm
            result['reference_angles'] = oracle['angles']
        return result

    def modem(self, phase, seconds):
        t = max(0, seconds-c.modem_latency_seconds) if phase == 'flight' else 0
        tick = math.floor(t*c.modem_rate_hz)
        key = phase, tick
        if self.modem_cache is None or self.modem_cache[0] != key:
            sat = self.orbit.at(tick/c.modem_rate_hz if phase == 'flight' else 0)
            rng = random.Random(f'modem:{c.seed}:{phase}:{tick}')
            value = ((sat['az']+rng.gauss(0,c.modem_noise_deg))%360,
                     max(-90,min(90,sat['el']+rng.gauss(0,c.modem_noise_deg))))
            self.modem_cache = key, value
        self.modem_calls += 1
        return self.modem_cache[1]

    def imu(self, phase, seconds):
        t = max(0, seconds-c.imu_latency_seconds) if phase == 'flight' else 0
        tick = math.floor(t*c.imu_rate_hz)
        key = phase, tick
        if self.imu_cache is None or self.imu_cache[0] != key:
            pose = self.pose(tick/c.imu_rate_hz if phase == 'flight' else 0)
            rng = random.Random(f'imu:{c.seed}:{phase}:{tick}')
            values = tuple(x+rng.gauss(0,c.imu_noise_deg) for x in pose)
            self.imu_cache = key, (values[0], values[1], values[2]%360)
        self.imu_calls += 1
        return self.imu_cache[1]
