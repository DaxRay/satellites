"""Публичный интерфейс, который main.py использует и в стенде, и в прошивке.

В эмуляторе этот модуль подставляется в памяти. На Raspberry Pi реализуются
только эти функции в отдельном драйвере; алгоритм в main.py сохраняется.
"""

def A():
    """Измерение мощности приёмника, дБм."""
    raise RuntimeError('Нужен backend: эмулятор или драйвер модема Raspberry Pi')


def modem_angles():
    """(азимут, высота), градусы. Азимут от севера по часовой стрелке, высота от горизонта."""
    raise RuntimeError('Нужен backend модема')


def imu_angles():
    """(крен, тангаж, курс), градусы; ориентация платформы относительно местной ENU."""
    raise RuntimeError('Нужен backend IMU/AHRS')


def gyro_rates():
    """(wx, wy, wz), рад/с в осях платформы. Это НЕ углы Эйлера."""
    raise RuntimeError('Нужен backend гироскопа')


def move1(degrees=1):
    """Относительный поворот первого диска. В компонентном режиме возвращает сразу."""
    raise RuntimeError('Нужен backend двигателя')


def move2(degrees=360):
    """Относительный поворот второго диска. В компонентном режиме возвращает сразу."""
    raise RuntimeError('Нужен backend двигателя')


def stop1():
    raise RuntimeError('Нужен backend двигателя')


def stop2():
    raise RuntimeError('Нужен backend двигателя')


def set_angles(phi1, phi2):
    """Абсолютные углы, градусы; кратчайший поворот из текущего положения."""
    raise RuntimeError('Нужен backend двигателя')


def motor_angles():
    """Фактические углы двух дисков, градусы (энкодеры или учёт шагов)."""
    raise RuntimeError('Нужен backend энкодеров')


def motors_busy():
    """(bool, bool): какие из двух двигателей сейчас движутся."""
    raise RuntimeError('Нужен backend двигателя')


def sleep(seconds):
    import time
    time.sleep(seconds)


def clock():
    import time
    return time.monotonic()


def utc_time():
    """Unix UTC для распространения TLE. В замороженном тесте не движется."""
    import time
    return time.time()
