import json
import math
import multiprocessing as mp
import sys
import time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import config as c
import vectors as v
from model import validate
from runner import run
from prisms import geometry

bg, panel = '#0b1422', '#132239'
text, muted = '#e6edf6', '#9eb0c7'
blue, green, amber = '#61c8ff', '#68e7b4', '#ffbd73'
state = result = process = pipe = None
meta = {}
history = []
yaw, tilt = -50, 27
mouse = None
main_path = Path(__file__).resolve().parent.parent/'main.py'


def project(point):
    x,y,z = point
    a,b = math.radians(yaw),math.radians(tilt)
    xx = x*math.cos(a)-y*math.sin(a)
    yy = x*math.sin(a)+y*math.cos(a)
    scale = min(scene.winfo_width()/12,scene.winfo_height()/8.5)
    return scene.winfo_width()*0.48+scale*xx, scene.winfo_height()*0.81-scale*(yy*math.sin(b)+z*math.cos(b))


def line(points, color, width=2, dash=None):
    xy=[]
    for p in points:
        xy.extend(project(p))
    scene.create_line(*xy,fill=color,width=width,dash=dash)


def label(point, name, color=muted):
    x,y=project(point)
    scene.create_text(x+8,y,text=name,fill=color,anchor='w',font=('Segoe UI',9))


def body(point):
    return v.scale(v.matvec(state['sat']['rotation'],point),1/c.prism_radius_m)


def prism(zin,zout,wedge,phi,color):
    bottom,top=[],[]
    a,b=math.radians(phi),math.radians(wedge)
    for i in range(48):
        angle=i*2*math.pi/48
        x,y=c.prism_radius_m*math.cos(angle),c.prism_radius_m*math.sin(angle)
        bottom.append(body((x,y,zin)))
        top.append(body((x,y,zout-math.tan(b)*(x*math.cos(a)+y*math.sin(a)))))
    faces=[bottom,top]+[[bottom[i],bottom[(i+1)%48],top[(i+1)%48],top[i]] for i in range(48)]
    # Порядок по проекции глубины достаточен для двух выпуклых тел в этой сцене.
    a,b=math.radians(yaw),math.radians(tilt)
    def depth(face):
        return sum((p[0]*math.sin(a)+p[1]*math.cos(a))*math.cos(b)-p[2]*math.sin(b) for p in face)/len(face)
    for face in sorted(faces,key=depth,reverse=True):
        xy=[]
        for p in face:
            xy.extend(project(p))
        scene.create_polygon(*xy,fill=color,outline='#405b78',width=1)
    # Метка на верхней грани показывает вращение даже у круглого диска.
    x,y=c.prism_radius_m*0.85*math.cos(a),c.prism_radius_m*0.85*math.sin(a)
    # Здесь a камеры; для метки используем именно угол диска.
    x,y=c.prism_radius_m*0.85*math.cos(math.radians(phi)),c.prism_radius_m*0.85*math.sin(math.radians(phi))
    zz=zout-math.tan(math.radians(wedge))*(x*math.cos(math.radians(phi))+y*math.sin(math.radians(phi)))
    line([body((0,0,zout+0.001)),body((x,y,zz+0.001))],text,3)


def draw_scene():
    scene.delete('all')
    if not state:
        scene.create_text(24,25,anchor='nw',text='Подготовка SGP4 и геометрии призм…',fill=muted,font=('Segoe UI',12))
        return
    for i in range(-3,4):
        line([(i,-3,0),(i,3,0)],'#273b54',1)
        line([(-3,i,0),(3,i,0)],'#273b54',1)
    for end,name,col in [((3,0,0),'E / Восток',blue),((0,3,0),'N / Север',green),((0,0,3),'U / Вверх',text)]:
        line([(0,0,0),end],col,2)
        label(end,name,col)
    # Неподвижный местный горизонт и наклонённая платформа — разные плоскости.
    corners=[body((x*c.prism_radius_m,y*c.prism_radius_m,-0.008)) for x,y in [(-1.25,-1.25),(1.25,-1.25),(1.25,1.25),(-1.25,1.25)]]
    coords=[]
    for p in corners: coords.extend(project(p))
    scene.create_polygon(*coords,fill='#203d53',outline='#56718b')
    antenna=[]
    for i in range(65):
        a=i*2*math.pi/64
        antenna.extend(project(body((c.feed_diameter_m/2*math.cos(a),c.feed_diameter_m/2*math.sin(a),0))))
    scene.create_polygon(*antenna,fill='#36586c',outline='#8ca6b8',width=2)
    label(body((c.feed_diameter_m/2,0,0)),'Антенна',muted)
    z1,z1o,z2,z2o=geometry()
    prism(z1,z1o,c.wedge1_deg,state['phig1'],'#296a8b')
    prism(z2,z2o,c.wedge2_deg,state['phig2'],'#937044')
    ray=state['ray']
    if len(ray['path'])>1:
        line([body(p) for p in ray['path']],blue,4)
    if ray['valid']:
        end=v.add(ray['path'][-1],v.scale(ray['direction'],0.5))
        line([body(ray['path'][-1]),body(end)],blue,4)
        label(body(end),'Луч',blue)
    else:
        scene.create_text(20,80,anchor='nw',text=ray['reason'],fill=amber,font=('Segoe UI',11))
    if state['sat']['visible']:
        target=v.scale(state['sat']['vector'],5.0)
        line([(0,0,0),target],green,2,(5,5))
        x,y=project(target)
        scene.create_rectangle(x-20,y-5,x+20,y+5,fill='#397c98',outline=green)
        scene.create_rectangle(x-5,y-10,x+5,y+10,fill=text,outline=green)
        scene.create_text(x,y-22,text='СПУТНИК',fill=green,font=('Segoe UI',10,'bold'))
    scene.create_text(18,16,anchor='nw',text='3D / потяни мышью для поворота',fill=muted,font=('Segoe UI',11))
    scene.create_text(18,42,anchor='nw',text='Четыре преломления • без приближения малых углов',fill=muted,font=('Segoe UI',10))


def sky_point(direction):
    az,el=v.vector_azel(direction)
    w,h=sky.winfo_width(),sky.winfo_height()
    r=min(w,h)*0.36
    k=(90-el)/90
    return w/2+r*k*math.sin(math.radians(az)),h/2-r*k*math.cos(math.radians(az))


def draw_sky():
    sky.delete('all')
    w,h=sky.winfo_width(),sky.winfo_height()
    cx,cy,r=w/2,h/2,min(w,h)*0.36
    for el in (0,30,60):
        rr=r*(90-el)/90
        sky.create_oval(cx-rr,cy-rr,cx+rr,cy+rr,outline='#3b506b')
        sky.create_text(cx+rr-8,cy+9,text=f'{el}°',fill=muted,font=('Segoe UI',8))
    for x,y,name in [(cx,cy-r-14,'С'),(cx+r+14,cy,'В'),(cx,cy+r+14,'Ю'),(cx-r-14,cy,'З')]:
        sky.create_text(x,y,text=name,fill=text)
    if not state:return
    for theta in (state['steering_min'],state['steering_max']):
        previous=None
        for i in range(97):
            phi=i*2*math.pi/96
            a=math.radians(theta)
            d=v.matvec(state['sat']['rotation'],(math.sin(a)*math.cos(phi),math.sin(a)*math.sin(phi),math.cos(a)))
            point=sky_point(d)
            if d[2]>=0 and previous:
                sky.create_line(*previous,*point,fill=amber,width=1)
            previous=point if d[2]>=0 else None
    if state['sat']['visible']:
        x,y=sky_point(state['sat']['vector'])
        sky.create_oval(x-5,y-5,x+5,y+5,fill=green,outline=green)
    if state['ray']['valid']:
        d=v.matvec(state['sat']['rotation'],state['ray']['direction'])
        if d[2]>0:
            x,y=sky_point(d)
            sky.create_line(x-6,y,x+6,y,fill=blue,width=2)
            sky.create_line(x,y-6,x,y+6,fill=blue,width=2)


def plot(canvas,series,limits,xlim,threshold=None):
    canvas.delete('all')
    w,h=canvas.winfo_width(),canvas.winfo_height()
    left,right,top,bottom=42,w-15,12,h-25
    lo,hi=limits
    def xy(t,y):
        return left+(right-left)*(t-xlim[0])/max(1e-9,xlim[1]-xlim[0]),top+(bottom-top)*(hi-max(lo,min(hi,y)))/(hi-lo)
    for y in (lo,(lo+hi)/2,hi):
        _,yy=xy(xlim[0],y)
        canvas.create_line(left,yy,right,yy,fill='#2c405b')
        canvas.create_text(19,yy,text=f'{y:g}',fill=muted,font=('Segoe UI',8))
    if threshold is not None:
        _,yy=xy(xlim[0],threshold)
        canvas.create_line(left,yy,right,yy,fill=amber,dash=(3,4))
    for values,color in series:
        if len(values)<2:continue
        points=[]
        for t,y in values:points.extend(xy(t,y))
        canvas.create_line(*points,fill=color,width=2)
    for t,anchor in [(xlim[0],'w'),(xlim[1],'e')]:
        x,_=xy(t,lo)
        canvas.create_text(x,h-10,text=f'{t:.1f} с',anchor=anchor,fill=muted,font=('Segoe UI',8))
    return xy


def draw():
    draw_scene();draw_sky()
    if not state:return
    sat=state['sat']
    stage='ПОИСК / неподвижная цель' if state['phase']=='search' else 'СОПРОВОЖДЕНИЕ / TLE + движение платформы'
    phase_text.set(f'{stage}   •   {state["seconds"]:.2f} с')
    mode='шаги' if state['motor_mode']=='step' else 'вращение'
    readout.set(f'{state["power"]:.2f} дБм    |    ошибка {state["error"]:.3f}°')
    angles_text.set(f'Диски: {state["phig1"]:.2f}° / {state["phig2"]:.2f}°    •    {mode}')
    r,p,y=sat['pose']
    pose_text.set(f'Крен {r:+.2f}°   Тангаж {p:+.2f}°   Курс {y%360:.2f}°')
    zone='Доступен для связи' if state['serviceable'] else ('Виден, вне доступного наведения' if sat['visible'] else 'За горизонтом')
    satellite_text.set(f'Азимут {sat["az"]:.2f}°   Высота {sat["el"]:.2f}°\nДальность {sat["range"]:.1f} км   •   {zone}')
    counters.set(f'A(): {state["measurements"]:,}    Модем: {state["modem_calls"]:,}    IMU: {state["imu_calls"]:,}    Команд: {state["moves"]:,}'.replace(',',' '))
    t0=history[0][0] if history else 0
    t1=max(t0+1,history[-1][0]) if history else 1
    plot(signal_plot,[([(t,h) for t,h,ref,pose in history],blue), ([(t,ref) for t,h,ref,pose in history],green)],
         (c.floor_dbm,max(-60,c.link_threshold_dbm+10)),(t0,t1),c.link_threshold_dbm)
    forecast=meta.get('forecast',[])
    xy=plot(orbit_plot,[(forecast,green)],(-30,90),(0,c.flight_seconds),0)
    if xy:
        t=state['seconds'] if state['phase']=='flight' else 0
        x,y=xy(t,sat['el'])
        orbit_plot.create_line(x,10,x,orbit_plot.winfo_height()-25,fill=amber,dash=(3,4))


def fmt(x,unit=''):
    return '—' if x is None else f'{x:.3f}{unit}'


def report_text(report):
    a,f=report['search'],report['flight']
    lines=['ИСПЫТАНИЕ MAIN.PY',f'Физика: четыре грани, закон Снеллиуса. Материал Rexolite 1422.',
           f'TLE: {report["tle_name"]}',f'Начало: {report["start_utc"]}; от эпохи TLE {report["tle_age_days"]:.3f} суток.',
           f'Запуск: {report["execution_mode"]}; привод: {report["motor_mode"]}.',
           '', '1. ПЕРВОНАЧАЛЬНЫЙ ПОИСК',f'Длительность: {a["seconds"]:.3f} с; измерений: {a["measurements"]}.',
           f'Первый контакт: {fmt(a["first_lock"]," с")}; устойчивый захват: {fmt(a["stable_lock_seconds"]," с")}.']
    if a['answer']:
        lines += [f'Выданные углы: {a["answer"][1]:.4f}° / {a["answer"][2]:.4f}°.',
                  f'Ошибка ответа: {a["answer_error"]:.4f}°; сигнал в этих углах без шума: {a["answer_power"]:.3f} дБм.',
                  f'Потеря к численному эталону: {a["gap_db"]:.4f} дБ.']
    else:lines.append('Алгоритм не выдал распознаваемого ответа с двумя углами.')
    lines += [f'Фактический сигнал после поиска: {a["actual_power"]:.3f} дБм.',
              '', '2. СОПРОВОЖДЕНИЕ',f'Проверено: {f["seconds"]:.3f} с; над горизонтом: {f["visible_seconds"]:.3f} с.',
              f'Геометрически достижим: {f["reachable_seconds"]:.3f} с; доступен по бюджету связи: {f["serviceable_seconds"]:.3f} с.',
              f'Связь в доступное время: {fmt(f["linked_percent"]," %")}.',
              f'RMS ошибки: {fmt(f["rms_error"],"°")}; P95: {fmt(f["p95_error"],"°")}; максимум: {fmt(f["max_error"],"°")}.',
              f'Средняя потеря к эталону: {fmt(f["mean_loss_db"]," дБ")}; P95: {fmt(f["p95_loss_db"]," дБ")}.',
              f'Самая долгая потеря связи: {f["longest_loss"]:.3f} с; восстановлений: {len(f["recovery_events"])}.',
              f'Модем опрошен {f["modem_calls"]} раз; IMU — {f["imu_calls"]} раз.',
              f'Движений {f["moves"]}; суммарный заданный ход {f["travelled_deg"]:.3f}°.',
              'Фактические углы первого этапа сохраняются. Стенд не наводит антенну вместо алгоритма.']
    if not f['controller_seen']:lines.append('Вызовов сопровождения не было: проверь наличие track_step() либо цикла в скрипте.')
    if report['error']:lines += ['', 'ОШИБКА В ПОЛЬЗОВАТЕЛЬСКОМ КОДЕ',report['error']]
    lines += ['',f'Дискретность оценки: {c.sample_seconds} с. Эталон численный; его разрешение {360/c.oracle_relative_samples:.3f}° по взаимному углу.',
              'Это геометрическая оптика центрального луча. Дифракция, многолучевость и полный расчёт поля здесь не моделируются.',
              'TEME→вращающаяся Земля: GMST, без UT1-поправок и полярного движения. TLE не является точной эфемеридой.']
    return '\n'.join(lines)


def show_report(content):
    report_box.configure(state='normal');report_box.delete('1.0','end')
    report_box.insert('1.0',content);report_box.configure(state='disabled')


def stop():
    global process,pipe
    if process is not None:
        if process.is_alive():process.terminate()
        process.join(timeout=1);process.close();process=None
    if pipe is not None:pipe.close();pipe=None


def read_settings():
    values={}
    for name,var in fields.items():
        old=getattr(c,name)
        if isinstance(old,bool):value=bool(var.get())
        elif isinstance(old,str):value=var.get().strip()
        else:
            value=float(var.get().replace(',','.'))
            if isinstance(old,int):
                if not value.is_integer():raise ValueError(name+' должно быть целым')
                value=int(value)
        values[name]=value
    old={name:getattr(c,name) for name in values}
    try:
        for name,value in values.items():setattr(c,name,value)
        validate()
    except Exception:
        for name,value in old.items():setattr(c,name,value)
        raise
    return values


def start():
    global state,result,history,process,pipe,acceleration,last_message,meta
    stop()
    try:
        settings=read_settings()
        if not main_path.exists():raise ValueError('Не найден '+str(main_path))
    except Exception as ex:
        messagebox.showerror('Настройки',str(ex));return
    state=result=None;history=[];meta={}
    ctx=mp.get_context('spawn')
    pipe,child=ctx.Pipe(duplex=False)
    acceleration=ctx.Value('d',float(speed.get()))
    process=ctx.Process(target=run,args=(str(main_path),child,acceleration,settings))
    process.start();child.close();last_message=time.monotonic()
    status.set('Строится геометрия и выбирается пролёт TLE. Затем запускается '+main_path.name)
    show_report('Идёт испытание. Алгоритм берётся из '+str(main_path))
    tabs.select(observe);draw_scene()


def poll():
    global state,result,history,pipe,meta,last_message
    changed=False
    if process is not None:acceleration.value=float(speed.get())
    if pipe is not None:
        try:
            for _ in range(100):
                if not pipe.poll():break
                kind,value=pipe.recv();last_message=time.monotonic()
                if kind=='ready':
                    meta=value
                    status.set(f'{value["tle_name"]} / {value["start_utc"]} / выполняется {main_path.name}')
                elif kind=='frame':
                    if state and state['phase']!=value['phase']:history=[]
                    state=value
                    history.append((value['seconds'],value['power'],value['reference'],value['sat']['pose']))
                    history=history[-600:];changed=True
                elif kind=='search_result':show_report('Поиск завершён. Идёт полёт.\n'+json.dumps(value,ensure_ascii=False,indent=2))
                elif kind=='done':
                    result=value;show_report(report_text(value))
                    status.set('Готово. '+('В main.py есть ошибка — смотри отчёт.' if value['error'] else 'Результаты на вкладке «Отчёт».'))
                elif kind=='error':show_report(value);status.set('Ошибка — смотри отчёт.')
        except (EOFError,OSError):pipe.close();pipe=None
    if process is not None and process.is_alive() and time.monotonic()-last_message>c.wall_timeout_seconds:
        stop();status.set('Проверка остановлена по тайм-ауту.');show_report('Код слишком долго не обращался к интерфейсу оборудования.')
    if changed:draw()
    root.after(40,poll)


def save():
    if result is None:messagebox.showinfo('Отчёт','Дождись завершения.');return
    folder=Path(__file__).with_name('reports');folder.mkdir(exist_ok=True)
    stem=time.strftime('test_%Y%m%d_%H%M%S')
    (folder/(stem+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/(stem+'.txt')).write_text(report_text(result),encoding='utf-8')
    status.set('Отчёт сохранён в '+str(folder))


def choose():
    global main_path
    name=filedialog.askopenfilename(title='Алгоритм main.py',filetypes=[('Python','*.py')],initialdir=str(main_path.parent))
    if name:main_path=Path(name);start()


def drag_start(e):
    global mouse
    mouse=e.x,e.y


def drag(e):
    global mouse,yaw,tilt
    if mouse:
        yaw+=(e.x-mouse[0])*0.5;tilt=max(5,min(80,tilt+(e.y-mouse[1])*0.3))
        mouse=e.x,e.y;draw_scene()


def main():
    global root,scene,sky,orbit_plot,signal_plot,tabs,observe,report_box,fields
    global phase_text,readout,angles_text,pose_text,satellite_text,counters,status,speed
    if sys.platform=='win32':
        import ctypes
        ctypes.windll.user32.SetProcessDPIAware()
    root=tk.Tk();root.title('RISLEY LAB v2 • точная геометрия / TLE / main.py')
    root.geometry(f'{min(1400,root.winfo_screenwidth()-60)}x{min(940,root.winfo_screenheight()-100)}+20+20')
    root.minsize(1050,780);root.configure(bg=bg)
    style=ttk.Style();style.theme_use('clam')
    style.configure('TButton',background='#274462',foreground=text,padding=7)
    style.configure('TNotebook',background=bg,borderwidth=0)
    style.configure('TNotebook.Tab',background='#223952',foreground=text,padding=(14,7))
    style.map('TNotebook.Tab',background=[('selected','#396d8e')])
    tk.Label(root,text='RISLEY LAB  /  физический стенд',bg=bg,fg=text,font=('Segoe UI',21,'bold')).pack(anchor='w',padx=18,pady=(12,3))
    controls=tk.Frame(root,bg=bg);controls.pack(fill='x',padx=18,pady=5)
    for name,cmd in [('Проверить main.py',start),('Выбрать алгоритм',choose),('Остановить',stop),('Сохранить отчёт',save)]:
        ttk.Button(controls,text=name,command=cmd).pack(side='left',padx=(0,7))
    tk.Label(controls,text='Показ ×',bg=bg,fg=muted).pack(side='left')
    speed=tk.Scale(controls,from_=1,to=1000,orient='horizontal',bg=bg,fg=text,highlightthickness=0,length=190)
    speed.set(c.speed);speed.pack(side='left')
    tabs=ttk.Notebook(root);tabs.pack(fill='both',expand=True,padx=18,pady=8)
    observe,settings,report=[tk.Frame(tabs,bg=panel) for _ in range(3)]
    for f,name in [(observe,'Наблюдение'),(settings,'Физика и сценарий'),(report,'Отчёт')]:tabs.add(f,text=name)
    phase_text,readout,angles_text,pose_text,satellite_text,counters,status=[tk.StringVar() for _ in range(7)]
    tk.Label(observe,textvariable=phase_text,bg=panel,fg=amber,font=('Segoe UI',12)).pack(pady=7)
    body_frame=tk.Frame(observe,bg=panel);body_frame.pack(fill='both',expand=True)
    left=tk.Frame(body_frame,bg=panel);left.pack(side='left',fill='both',expand=True)
    right=tk.Frame(body_frame,bg=panel,width=400);right.pack(side='right',fill='y')
    scene=tk.Canvas(left,bg=panel,height=100,width=100,highlightthickness=0);scene.pack(fill='both',expand=True)
    scene.bind('<Button-1>',drag_start);scene.bind('<B1-Motion>',drag);scene.bind('<Configure>',lambda e:draw_scene())
    for var,size,col in [(readout,19,blue),(angles_text,10,text),(pose_text,10,amber)]:
        tk.Label(left,textvariable=var,bg=panel,fg=col,font=('Segoe UI',size)).pack(pady=2)
    tk.Label(left,text='Синий — фактический сигнал • зелёный — численный эталон • пунктир — порог связи',bg=panel,fg=muted,font=('Segoe UI',9)).pack(pady=(5,0))
    signal_plot=tk.Canvas(left,height=135,bg=panel,highlightthickness=0);signal_plot.pack(fill='x')
    tk.Label(right,text='НЕБО ОТНОСИТЕЛЬНО ЗЕМЛИ',bg=panel,fg=text,font=('Segoe UI',11,'bold')).pack()
    sky=tk.Canvas(right,width=400,height=230,bg=panel,highlightthickness=0);sky.pack(fill='both',expand=True)
    tk.Label(right,text='Зелёная точка — спутник. Синий крест — луч.\nКрай — горизонт; центр — над головой.\nОранжевый контур — поле призм с учётом\nнаклона платформы. Внутренняя дыра недоступна.',bg=panel,fg=muted,justify='left',font=('Segoe UI',9)).pack()
    tk.Label(right,textvariable=satellite_text,bg=panel,fg=green,font=('Segoe UI',10),wraplength=390).pack(pady=8)
    tk.Label(right,text='ВЫСОТА СПУТНИКА / ВРЕМЯ ПОЛЁТА',bg=panel,fg=text,font=('Segoe UI',10)).pack()
    orbit_plot=tk.Canvas(right,width=400,height=160,bg=panel,highlightthickness=0);orbit_plot.pack(fill='x')
    tk.Label(observe,textvariable=counters,bg=panel,fg=muted,font=('Segoe UI',9)).pack(side='bottom',before=body_frame,pady=6)
    tk.Label(settings,text='Параметры применяются при новом испытании. Постоянные значения — config.py.\nДля TLE используется эпоха и найденный пролёт. Впиши start_utc с часовым поясом для своего времени.\nПараметры алгоритма и его логика остаются в main.py.',bg=panel,fg=text,justify='left').pack(anchor='w',padx=15,pady=10)
    scroll=tk.Canvas(settings,bg=panel,highlightthickness=0);sb=ttk.Scrollbar(settings,orient='vertical',command=scroll.yview)
    sb.pack(side='right',fill='y');scroll.pack(side='left',fill='both',expand=True);scroll.configure(yscrollcommand=sb.set)
    form=tk.Frame(scroll,bg=panel);scroll.create_window((0,0),window=form,anchor='nw')
    form.bind('<Configure>',lambda e:scroll.configure(scrollregion=scroll.bbox('all')))
    fields={};comments={}
    for ln in Path(c.__file__).read_text(encoding='utf-8-sig').splitlines():
        if '=' in ln and '#' in ln and not ln.lstrip().startswith('#'):comments[ln.split('=')[0].strip()]=ln.split('#',1)[1].strip()
    row=0
    for name,value in vars(c).items():
        if name.startswith('_') or not isinstance(value,(str,int,float,bool)):continue
        tk.Label(form,text=name,bg=panel,fg=blue,font=('Segoe UI',10)).grid(row=row,column=0,sticky='w',padx=14,pady=4)
        if isinstance(value,bool):
            var=tk.BooleanVar(value=value);widget=tk.Checkbutton(form,variable=var,bg=panel,selectcolor=bg)
        else:
            var=tk.StringVar(value=str(value))
            if name=='motor_mode':widget=ttk.Combobox(form,textvariable=var,values=('auto','step','continuous'),state='readonly',width=12)
            else:widget=tk.Entry(form,textvariable=var,width=70 if name.startswith('tle') or name=='start_utc' else 13,bg=bg,fg=text,insertbackground=text)
        widget.grid(row=row,column=1,sticky='w',padx=8)
        tk.Label(form,text=comments.get(name,''),bg=panel,fg=muted,wraplength=420,justify='left').grid(row=row,column=2,sticky='w',padx=8)
        fields[name]=var;row+=1
    report_box=tk.Text(report,wrap='word',bg=panel,fg=text,padx=18,pady=15,font=('Segoe UI',11),relief='flat')
    sb=ttk.Scrollbar(report,orient='vertical',command=report_box.yview);sb.pack(side='right',fill='y')
    report_box.configure(yscrollcommand=sb.set);report_box.pack(fill='both',expand=True)
    tk.Label(root,textvariable=status,bg=bg,fg=amber,wraplength=1300,font=('Segoe UI',9)).pack(side='bottom',before=tabs,pady=(0,9))
    root.protocol('WM_DELETE_WINDOW',lambda:(stop(),root.destroy()))
    root.after(40,poll);root.after(500,start);root.mainloop()


if __name__=='__main__':
    mp.freeze_support()
    if len(sys.argv)>2 and sys.argv[1]=='--main':main_path=Path(sys.argv[2]).resolve()
    main()
